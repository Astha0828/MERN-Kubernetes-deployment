const express = require("express");
// 

const routes = express.Router();

routes.post("/info", Register);



module.exports = routes;